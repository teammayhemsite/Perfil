console.log("VOCE NAO VAI GANHAR NADA FAZENDO ISSO");

// =========================
// CADASTRO
// =========================

const registerBtn =
  document.getElementById("register-btn");

if (registerBtn) {

  registerBtn.addEventListener("click", async () => {

    const user =
      document.getElementById("register-user").value;

    const pass =
      document.getElementById("register-pass").value;

    const usernameRegex = /^[a-z0-9_]{3,20}$/;

    if (!usernameRegex.test(user)) {
      alert(
        "O usuário deve ter entre 3 e 20 caracteres e conter apenas letras, números e _"
      );
      return;
    }

    if (!user || !pass) {

      alert("Preencha tudo");
      return;

    }

    const { data: existing } = await supabaseClient
      .from("profiles")
      .select("id")
      .eq("username", user)
      .maybeSingle();

    if (existing) {
      document.getElementById("register-error").textContent =
        "*nome de usuário em uso";
      return;
    }

    const { data, error } =
      await supabaseClient.auth.signUp({

        email: `${user}@fake.com`,
        password: pass

      });

    console.log(data);
    console.log(error);

    if (error) {

      alert(error.message);
      return;

    }

    alert("Conta criada!");

    window.location.href =
      "login.html";

  });

}

// =========================
// LOGIN
// =========================

const loginBtn =
  document.getElementById("login-btn");

if (loginBtn) {

  loginBtn.addEventListener("click", async () => {

    const user =
      document.getElementById("login-user").value;

    const pass =
      document.getElementById("login-pass").value;

    const { data, error } =
      await supabaseClient.auth.signInWithPassword({

        email: `${user}@fake.com`,
        password: pass

      });

    console.log(data);
    console.log(error);

    if (error) {

      const errBox = document.getElementById("login-error");
      errBox.textContent = "*usuário ou senha incorreto!";
      return;

    }
    // REDIRECIONA PARA O DASHBOARD
    window.location.href =
      "dashboard.html";

  });

}
